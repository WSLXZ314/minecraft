package com.ancientextra;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import slimeknights.tconstruct.library.materials.stats.MaterialStatsId;
import slimeknights.tconstruct.library.tools.part.ToolPartItem;

@Mod(AncientExtra.MODID)
public class AncientExtra {
    public static final String MODID = "ancientextra";

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MODID);

    /**
     * "Swasher Tank" part. Uses the plating stat type so it can contribute stats
     * when assembled into a tool, and because it extends ToolPartItem it counts as
     * a Tinkers part (it can be stored in the part chest and used in the tool station).
     */
    public static final RegistryObject<Item> SWASHER_TANK = ITEMS.register("swasher_tank",
            () -> new ToolPartItem(new Item.Properties(), new MaterialStatsId("tconstruct", "plating")));

    private static final String[] CONTENT = {
            "tinkersancient:battlesign_head",
            "tinkersancient:battlesign_handle",
            "tinkersancient:melting_pan_head",
            "tinkersancient:melting_pan_handle",
            "tinkersancient:war_pick_handle",
            "tinkersancient:war_pick_limb",
            "tinkersancient:battlesign_head_cast",
            "tinkersancient:battlesign_handle_cast",
            "tinkersancient:melting_pan_head_cast",
            "tinkersancient:melting_pan_handle_cast",
            "tinkersancient:war_pick_handle_cast",
            "tinkersancient:war_pick_limb_cast",
            "tinkersancient:battlesign",
            "tinkersancient:melting_pan",
            "tinkersancient:war_pick",
            "tconstruct:swasher"
    };

    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.ancientextra"))
            .icon(() -> new ItemStack(Items.GOLD_INGOT))
            .displayItems((params, output) -> {
                output.accept(SWASHER_TANK.get());
                for (String id : CONTENT) {
                    Item item = ForgeRegistries.ITEMS.getValue(new ResourceLocation(id));
                    if (item != null) {
                        output.accept(item);
                    }
                }
            })
            .build());

    public AncientExtra() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        TABS.register(bus);
    }
}
