# Ancient Extra — 喷流储罐 / 远古匠艺扩展

Forge 1.20.1 附属模组，给匠魂加一个「喷流储罐」部件，并把远古匠艺的部件/铸模放进独立创造栏。

## 内容

| 内容 | 说明 |
|---|---|
| `ancientextra:swasher_tank`（喷流储罐） | 匠魂部件，继承 `ToolPartItem`，可放部件箱、可用于部件台，统计类型复用 `tconstruct:plating` |
| 工作台配方 | 1 × 背包储罐（`travelersbackpack:backpack_tank`）+ 1 × 铁锭 → 2 × 喷流储罐 |
| 贴图 | 直接引用 `travelersbackpack:item/backpack_tank`，外观与背包储罐一致 |
| 创造栏 | 新增「远古匠艺扩展」页，含 6 个远古部件、6 个铸模、3 把远古工具、喷流刃、喷流储罐 |

## 编译步骤

需要 **JDK 17** 和能联网的环境（首次要下 ForgeGradle 与 Minecraft 依赖）。

```bash
# 项目根目录
./gradlew build          # Windows: gradlew.bat build
```

产物：`build/libs/ancientextra-1.0.0.jar`

把 jar 放进 `.minecraft` 对应整合包目录的 `mods/` 即可。

## 依赖

- Forge 1.20.1-47.2.0（编译用）
- Tinkers' Construct 3.11.2.166（已放在 `libs/`，`build.gradle` 用 `fg.deobf(files(...))` 引入）
- 运行时需要：匠魂本体、远古匠艺、旅行者背包（贴图来源）

## 装好之后还要做的一步

模组只提供「喷流储罐」这个部件物品；要让喷流刃用上它，需要把数据包
`data/tconstruct/tinkering/tool_definitions/swasher.json` 里的 `parts` 列表
替换成：

```json
["tconstruct:tough_handle", "tconstruct:broad_blade", "tconstruct:large_plate", "ancientextra:swasher_tank"]
```

对应 `station_layouts/swasher.json` 也要加一个槽位：

```json
{ "filter": { "item": "ancientextra:swasher_tank" }, "icon": "ancientextra:swasher_tank", "translation_key": "item.ancientextra.swasher_tank", "x": 64, "y": 20 }
```

## 已知问题

本机（Windows + DSH 沙箱 + ForgeGradle 6.0.54）编译时，ForgeGradle 的
AccessTransformer 步骤报 `java.nio.file.ReadOnlyFileSystemException`，
更换 MDK 版本、清缓存、换 JDK 17.0.9 均无效。属于该环境与 ForgeGradle 的兼容问题，
换一台干净机器编译即可。
